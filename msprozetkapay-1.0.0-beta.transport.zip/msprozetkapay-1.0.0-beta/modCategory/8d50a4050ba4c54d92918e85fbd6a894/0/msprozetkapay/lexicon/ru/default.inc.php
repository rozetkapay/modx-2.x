<?php
/**
 * Default Russian Lexicon Entries for mspRozetkaPay
 *
 * @package msprozetkapay
 * @subpackage lexicon
 */

include_once 'setting.inc.php';

$_lang['msprozetkapay'] = 'mspRozetkaPay';