<?php
/**
 * Setting Russian Lexicon Entries for mspRozetkaPay
 *
 * @package msprozetkapay
 * @subpackage lexicon
 */

$_lang['area_msprozetkapay'] = 'Основные настройки';
$_lang['setting_msprozetkapay_login'] = 'Логин';
$_lang['setting_msprozetkapay_login_desc'] = '';
$_lang['setting_msprozetkapay_password'] = 'Пароль';
$_lang['setting_msprozetkapay_password_desc'] = '';
$_lang['setting_msprozetkapay_refound_status_id'] = 'Статус возврата денег';
$_lang['setting_msprozetkapay_refound_status_id_desc'] = 'Укажите ID статуса, который возвращает оплату. Оставьте пустым, если не хотите использовать фикцию возврата оплаты.';
$_lang['setting_msprozetkapay_success_id'] = 'Страница успешной оплаты';
$_lang['setting_msprozetkapay_success_desc'] = 'Укажите ID ресурса';
$_lang['setting_msprozetkapay_failure_id'] = 'Страница неуспешной оплаты';
$_lang['setting_msprozetkapay_failure_desc'] = 'Укажите ID ресурса';
$_lang['setting_msprozetkapay_currency'] = 'Валюта оплаты';