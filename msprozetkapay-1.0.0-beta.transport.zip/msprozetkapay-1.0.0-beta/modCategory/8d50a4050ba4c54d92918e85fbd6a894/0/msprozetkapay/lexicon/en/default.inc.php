<?php
/**
 * Default English Lexicon Entries for mspWayForPay
 *
 * @package mspwayforpay
 * @subpackage lexicon
 */

include_once 'setting.inc.php';

$_lang['msprozetkapay'] = 'mspRozetkaPay';