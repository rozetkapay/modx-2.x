--------------------
Components Name: mspRozetkaPay
Description: Custom payment gateway for RozetkaPay
Version: 1.0.0
Author: RozetkaPay
--------------------